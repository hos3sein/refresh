# Refresh service

## install

```
npm install
```

## run project

```
npm run dev
```

```
PORT : 6001
```

## Setting

```
globalSetting

all variable
all group
all category
```

## Content

```
globalContent

all content
```
